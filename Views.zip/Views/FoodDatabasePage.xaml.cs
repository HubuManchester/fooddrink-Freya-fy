﻿using NutriLens.Models;
using NutriLens.Services;

namespace NutriLens.Views;

/// <summary>
/// Food Database page - browse, search, add, edit and delete foods
/// </summary>
public partial class FoodDatabasePage : ContentPage
{
    private readonly DatabaseService _databaseService;
    private List<FoodItem> _allFoods = new List<FoodItem>();
    private List<FoodItem> _filteredFoods = new List<FoodItem>();

    public FoodDatabasePage(DatabaseService databaseService)
    {
        InitializeComponent();
        _databaseService = databaseService;
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        await LoadFoodsAsync();
    }

    /// <summary>
    /// Load all foods from database
    /// </summary>
    private async Task LoadFoodsAsync()
    {
        try
        {
            _allFoods = await _databaseService.GetAllFoodsAsync();
            _filteredFoods = _allFoods.ToList();
            UpdateDisplay();
        }
        catch (Exception ex)
        {
            await DisplayAlert("Error",
                $"Failed to load foods: {ex.Message}", "OK");
        }
    }

    /// <summary>
    /// Update list and stats display
    /// </summary>
    private void UpdateDisplay()
    {
        FoodList.ItemsSource = null;
        FoodList.ItemsSource = _filteredFoods;

        TotalFoodsLabel.Text = _allFoods.Count.ToString();
        AvgCaloriesLabel.Text = _allFoods.Any()
            ? $"{_allFoods.Average(f => f.Calories):F0}"
            : "0";
        CategoriesLabel.Text = _allFoods
            .Select(f => f.Category)
            .Distinct()
            .Count()
            .ToString();
    }

    /// <summary>
    /// Filter foods by search text
    /// </summary>
    private void OnSearchTextChanged(object sender, TextChangedEventArgs e)
    {
        string query = e.NewTextValue?.ToLower() ?? "";

        _filteredFoods = string.IsNullOrEmpty(query)
            ? _allFoods.ToList()
            : _allFoods.Where(f =>
                f.Name.ToLower().Contains(query) ||
                f.Category.ToLower().Contains(query))
              .ToList();

        FoodList.ItemsSource = null;
        FoodList.ItemsSource = _filteredFoods;
    }

    /// <summary>
    /// Show add food dialog
    /// </summary>
    private async void OnAddFoodClicked(object sender, EventArgs e)
    {
        await ShowFoodDialog(null);
    }

    /// <summary>
    /// Show food detail on tap
    /// </summary>
    private async void OnFoodTapped(object sender, TappedEventArgs e)
    {
        if (e.Parameter is not FoodItem food) return;

        await DisplayAlert(food.Name,
            $"Category: {food.Category}\n" +
            $"Calories: {food.Calories:F0} kcal\n" +
            $"Protein: {food.Protein:F1}g\n" +
            $"Fat: {food.Fat:F1}g\n" +
            $"Sugar: {food.Sugar:F1}g\n\n" +
            $"Swipe right to edit, left to delete.",
            "Close");
    }

    /// <summary>
    /// Edit food on right swipe
    /// </summary>
    private async void OnEditFoodSwiped(object sender, EventArgs e)
    {
        if (sender is SwipeItem swipeItem &&
            swipeItem.BindingContext is FoodItem food)
        {
            await ShowFoodDialog(food);
        }
    }

    /// <summary>
    /// Delete food on left swipe
    /// </summary>
    private async void OnDeleteFoodSwiped(object sender, EventArgs e)
    {
        if (sender is SwipeItem swipeItem &&
            swipeItem.BindingContext is FoodItem food)
        {
            bool confirm = await DisplayAlert("Delete Food",
                $"Delete {food.Name}?", "Delete", "Cancel");

            if (!confirm) return;

            bool success = await _databaseService.DeleteFoodAsync(food.Id);

            if (success)
            {
                Vibration.Default.Vibrate(TimeSpan.FromMilliseconds(200));
                await LoadFoodsAsync();
            }
            else
            {
                await DisplayAlert("Error",
                    "Failed to delete food.", "OK");
            }
        }
    }

    /// <summary>
    /// Show add/edit food dialog
    /// </summary>
    private async Task ShowFoodDialog(FoodItem? existingFood)
    {
        bool isEdit = existingFood != null;

        // Food name
        string name = await DisplayPromptAsync(
            isEdit ? "Edit Food" : "Add Food",
            "Food name:",
            "Next", "Cancel",
            existingFood?.Name ?? "",
            maxLength: 50);

        if (string.IsNullOrEmpty(name)) return;

        // Category
        string category = await DisplayActionSheet(
            "Select Category",
            "Cancel", null,
            "🥩 Meat", "🐟 Fish", "🥦 Vegetables",
            "🍎 Fruits", "🥛 Dairy", "🌾 Grains",
            "🍫 Snacks", "🥤 Drinks", "🍳 Other");

        if (category == "Cancel" || category == null) return;
        category = category.Substring(3); // Remove emoji prefix

        // Calories
        string caloriesText = await DisplayPromptAsync(
            isEdit ? "Edit Food" : "Add Food",
            "Calories (kcal per 100g):",
            "Next", "Cancel",
            existingFood?.Calories.ToString("F0") ?? "",
            keyboard: Keyboard.Numeric);

        if (string.IsNullOrEmpty(caloriesText)) return;

        if (!double.TryParse(caloriesText, out double calories) ||
            calories < 0 || calories > 9000)
        {
            await DisplayAlert("Validation Error",
                "Please enter valid calories (0-9000).", "OK");
            return;
        }

        // Protein
        string proteinText = await DisplayPromptAsync(
            isEdit ? "Edit Food" : "Add Food",
            "Protein (g per 100g):",
            "Next", "Cancel",
            existingFood?.Protein.ToString("F1") ?? "0",
            keyboard: Keyboard.Numeric);

        if (string.IsNullOrEmpty(proteinText)) return;

        if (!double.TryParse(proteinText, out double protein) ||
            protein < 0 || protein > 100)
        {
            await DisplayAlert("Validation Error",
                "Please enter valid protein (0-100g).", "OK");
            return;
        }

        // Fat
        string fatText = await DisplayPromptAsync(
            isEdit ? "Edit Food" : "Add Food",
            "Fat (g per 100g):",
            "Next", "Cancel",
            existingFood?.Fat.ToString("F1") ?? "0",
            keyboard: Keyboard.Numeric);

        if (string.IsNullOrEmpty(fatText)) return;

        if (!double.TryParse(fatText, out double fat) ||
            fat < 0 || fat > 100)
        {
            await DisplayAlert("Validation Error",
                "Please enter valid fat (0-100g).", "OK");
            return;
        }

        // Sugar
        string sugarText = await DisplayPromptAsync(
            isEdit ? "Edit Food" : "Add Food",
            "Sugar (g per 100g):",
            "Save", "Cancel",
            existingFood?.Sugar.ToString("F1") ?? "0",
            keyboard: Keyboard.Numeric);

        if (string.IsNullOrEmpty(sugarText)) return;

        if (!double.TryParse(sugarText, out double sugar) ||
            sugar < 0 || sugar > 100)
        {
            await DisplayAlert("Validation Error",
                "Please enter valid sugar (0-100g).", "OK");
            return;
        }

        try
        {
            var food = new FoodItem
            {
                Id = existingFood?.Id ?? 0,
                Name = name,
                Category = category,
                Calories = calories,
                Protein = protein,
                Fat = fat,
                Sugar = sugar
            };

            bool success = isEdit
                ? await _databaseService.UpdateFoodAsync(food)
                : await _databaseService.SaveFoodAsync(food);

            if (success)
            {
                Vibration.Default.Vibrate(TimeSpan.FromMilliseconds(200));
                await LoadFoodsAsync();
            }
            else
            {
                await DisplayAlert("Error",
                    "Failed to save food.", "OK");
            }
        }
        catch (Exception ex)
        {
            await DisplayAlert("Error",
                $"Failed to save: {ex.Message}", "OK");
        }
    }

    /// <summary>
    /// Handle pull to refresh
    /// </summary>
    private async void OnRefreshing(object sender, EventArgs e)
    {
        try
        {
            await LoadFoodsAsync();
        }
        finally
        {
            RefreshView.IsRefreshing = false;
        }
    }
}